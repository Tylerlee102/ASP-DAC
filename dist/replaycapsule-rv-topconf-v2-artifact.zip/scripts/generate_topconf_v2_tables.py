#!/usr/bin/env python3
"""Generate compact v2 paper tables and status figures from processed CSVs."""

from __future__ import annotations

from pathlib import Path

from topconf_eval_common import REPO_ROOT, read_csv


TABLE_DIR = REPO_ROOT / "paper/tables"
FIG_DIR = REPO_ROOT / "paper/figures"


def main() -> int:
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    _write_table_replay_consumer_tests()
    _write_table_buffer_sensitivity_v2()
    _write_table_capsule_baselines_v2()
    _write_table_runtime_scaling_v2()
    _write_table_mapped_scaling_v2()
    _write_limitations_table()
    _write_figures()
    print("WROTE v2 paper tables and figures")
    return 0


def _write_table_replay_consumer_tests() -> None:
    rows = read_csv(REPO_ROOT / "results/processed/replay_consumer_tests.csv")
    passed = sum(1 for row in rows if row.get("passed") == "true")
    total = len(rows)
    _write_tex(
        TABLE_DIR / "table_replay_consumer_tests.tex",
        [
            r"\begin{tabular}{lrr}",
            r"\toprule",
            r"Scope & Passed & Total \\",
            r"\midrule",
            f"Replay-consume RTL tests & {passed} & {total} " + r"\\",
            r"\bottomrule",
            r"\end{tabular}",
        ],
    )


def _write_table_buffer_sensitivity_v2() -> None:
    rows = [
        row
        for row in read_csv(REPO_ROOT / "results/processed/buffer_sensitivity_v2_summary.csv")
        if row.get("workload_scale") == "stress" and row.get("buffer_depth") in {"256", "512", "1024", "2048"}
    ]
    lines = [r"\begin{tabular}{llrrr}", r"\toprule", r"Arch & Config & Depth & Overflow \% & Replay success \% \\", r"\midrule"]
    for row in rows[:16]:
        lines.append(
            f"{_esc(row['architecture'])} & {_esc(row['recorder_config'])} & {row['buffer_depth']} & "
            f"{row['overflow_rate_pct']} & {_esc(row['replay_success_rate_pct'])} " + r"\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    _write_tex(TABLE_DIR / "table_buffer_sensitivity_v2.tex", lines)


def _write_table_capsule_baselines_v2() -> None:
    rows = [
        row
        for row in read_csv(REPO_ROOT / "results/processed/capsule_baseline_summary_v2.csv")
        if row.get("workload_scale") == "stress"
        and row.get("baseline") in {"full_instruction_trace", "full_commit_trace", "v1_replaycapsule_full", "v2_core", "v2_hashed", "v2_full"}
    ]
    lines = [r"\begin{tabular}{llrr}", r"\toprule", r"Baseline & Config & Median bytes & N \\", r"\midrule"]
    for row in rows:
        lines.append(f"{_esc(row['baseline'])} & {_esc(row['recorder_config'])} & {row['median_bytes']} & {row['n']} " + r"\\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    _write_tex(TABLE_DIR / "table_capsule_baselines_v2.tex", lines)


def _write_table_runtime_scaling_v2() -> None:
    rows = read_csv(REPO_ROOT / "results/processed/runtime_scaling_summary.csv")
    lines = [r"\begin{tabular}{lrrr}", r"\toprule", r"Config & Cycle overhead & Commit overhead & Notes \\", r"\midrule"]
    for row in rows[:6]:
        lines.append(
            f"{_esc(row.get('config', 'NA'))} & {_esc(row.get('median_cycle_overhead_pct', row.get('cycle_overhead_pct', 'NA')))} & "
            f"{_esc(row.get('median_commit_overhead_pct', row.get('commit_overhead_pct', 'NA')))} & v1 measured " + r"\\"
        )
    lines.append(r"v2 & NA & NA & blocked until full-core v2 runtime harness \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    _write_tex(TABLE_DIR / "table_runtime_scaling_v2.tex", lines)


def _write_table_mapped_scaling_v2() -> None:
    consumer = read_csv(REPO_ROOT / "results/processed/replay_consumer_mapped.csv")
    mapped = consumer[0] if consumer else {}
    lines = [
        r"\begin{tabular}{lrrrrl}",
        r"\toprule",
        r"Design & LUT & FF & BRAM & Fmax MHz & Scope \\",
        r"\midrule",
        f"v2 replay consumer & {_esc(mapped.get('lut', 'NA'))} & {_esc(mapped.get('ff', 'NA'))} & {_esc(mapped.get('bram', 'NA'))} & {_esc(mapped.get('fmax_mhz', 'NA'))} & standalone prototype " + r"\\",
        r"full-core v2 & NA & NA & NA & NA & blocked \\",
        r"\bottomrule",
        r"\end{tabular}",
    ]
    _write_tex(TABLE_DIR / "table_mapped_scaling_v2.tex", lines)


def _write_limitations_table() -> None:
    _write_tex(
        TABLE_DIR / "table_limitations.tex",
        [
            r"\begin{tabular}{lp{0.58\linewidth}}",
            r"\toprule",
            r"Topic & Current scope \\",
            r"\midrule",
            r"Core scope & Single-hart RV32I only \\",
            r"Replay consume & v2 synthesizable prototype; full-core integration blocked \\",
            r"v2 workload replay & Analytic capacity estimates only; no PASS claim \\",
            r"Mapped overhead & v1 full-core measured; v2 full-core blocked \\",
            r"ASIC/power & Not measured \\",
            r"\bottomrule",
            r"\end{tabular}",
        ],
    )


def _write_figures() -> None:
    summaries = {
        "fig_workload_scaling_v2.pdf": _workload_lines(),
        "fig_capsule_scaling_v2.pdf": _capsule_lines(),
        "fig_buffer_sensitivity_v2.pdf": _buffer_lines(),
        "fig_runtime_scaling_v2.pdf": ["Runtime scaling v2", "v1 runtime scaling exists.", "v2 full-core runtime is blocked."],
        "fig_mapped_overhead_v2.pdf": _mapped_lines(),
        "fig_recorder_config_tradeoff_v2.pdf": ["Recorder config tradeoff v2", "minimal/core/hashed/diagnostic/full are represented in analytic CSVs.", "Replay PASS requires future full-core v2 harness."],
        "fig_replay_consumer_controller.pdf": _consumer_lines(),
    }
    for name, lines in summaries.items():
        _write_pdf(FIG_DIR / name, lines)


def _workload_lines() -> list[str]:
    rows = read_csv(REPO_ROOT / "results/processed/workload_scaling_v2_summary.csv")
    v1_fail = sum(int(row["fail_count"]) for row in rows if row["architecture"] == "v1")
    v2_blocked = sum(int(row["blocked_count"]) for row in rows if row["architecture"] == "v2")
    return ["Workload scaling v2", f"v1 FAIL rows: {v1_fail}", f"v2 full-core rows blocked: {v2_blocked}", "No v2 replay PASS is claimed."]


def _capsule_lines() -> list[str]:
    rows = read_csv(REPO_ROOT / "results/processed/capsule_baseline_summary_v2.csv")
    stress = {row["baseline"]: row["median_bytes"] for row in rows if row.get("workload_scale") == "stress"}
    return ["Capsule scaling v2", f"v1 full median stress bytes: {stress.get('v1_replaycapsule_full', 'NA')}", f"v2 core estimated median stress bytes: {stress.get('v2_core', 'NA')}", "v2 sizes are estimates."]


def _buffer_lines() -> list[str]:
    rows = read_csv(REPO_ROOT / "results/processed/buffer_sensitivity_v2_summary.csv")
    core = [row for row in rows if row.get("recorder_config") == "core" and row.get("workload_scale") == "stress" and row.get("buffer_depth") == "256"]
    return ["Buffer sensitivity v2", f"v2 core stress overflow at depth 256: {core[0]['overflow_rate_pct'] if core else 'NA'}%", "Replay success is NA for v2 until measured."]


def _mapped_lines() -> list[str]:
    rows = read_csv(REPO_ROOT / "results/processed/replay_consumer_mapped.csv")
    row = rows[0] if rows else {}
    return ["Mapped overhead v2", f"Replay consumer ECP5-85k status: {row.get('status', 'NA')}", f"LUT={row.get('lut', 'NA')} FF={row.get('ff', 'NA')} Fmax={row.get('fmax_mhz', 'NA')} MHz", "Full-core v2 overhead is blocked."]


def _consumer_lines() -> list[str]:
    tests = read_csv(REPO_ROOT / "results/processed/replay_consumer_tests.csv")
    passed = sum(1 for row in tests if row.get("passed") == "true")
    return ["Replay-consume controller", f"RTL tests passed: {passed}/{len(tests)}", "Scope: synthesizable prototype, not full-core autonomous replay."]


def _write_tex(path: Path, lines: list[str]) -> None:
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_pdf(path: Path, lines: list[str]) -> None:
    content = ["BT", "/F1 16 Tf", "72 740 Td"]
    first = True
    for line in lines:
        if not first:
            content.append("0 -24 Td")
        content.append(f"({_pdf_esc(line)}) Tj")
        first = False
    content.append("ET")
    stream = "\n".join(content).encode("ascii", errors="replace")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    data = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for i, obj in enumerate(objects, start=1):
        offsets.append(len(data))
        data.extend(f"{i} 0 obj\n".encode("ascii"))
        data.extend(obj)
        data.extend(b"\nendobj\n")
    xref = len(data)
    data.extend(f"xref\n0 {len(objects)+1}\n0000000000 65535 f \n".encode("ascii"))
    for offset in offsets[1:]:
        data.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    data.extend(f"trailer << /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode("ascii"))
    path.write_bytes(data)


def _esc(value: object) -> str:
    return str(value).replace("_", r"\_").replace("%", r"\%")


def _pdf_esc(value: str) -> str:
    return value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


if __name__ == "__main__":
    raise SystemExit(main())

