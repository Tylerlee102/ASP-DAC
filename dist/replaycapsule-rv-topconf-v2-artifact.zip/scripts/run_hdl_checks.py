#!/usr/bin/env python3
"""Run available HDL frontend checks without requiring system-wide installs."""

from __future__ import annotations

import csv
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from dataclasses import field
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = REPO_ROOT / "results/raw"
OUT_CSV = REPO_ROOT / "results/processed/hdl_checks.csv"
BUILD_DIR = REPO_ROOT / ".tools/hdl_checks"
OSS_CAD_SUITE = REPO_ROOT / ".tools/oss-cad-suite/oss-cad-suite"


@dataclass(frozen=True)
class Tool:
    command: str
    label: str
    env: dict[str, str]


@dataclass(frozen=True)
class IverilogTest:
    name: str
    workdir: Path
    sources: tuple[str, ...]
    include_dirs: tuple[str, ...]
    run_args: tuple[str, ...] = field(default_factory=tuple)
    defines: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class VerilatorLintTarget:
    name: str
    top: str
    sources: tuple[str, ...]
    include_dirs: tuple[str, ...]


PICORV32_WRAPPER_V2_SOURCES = (
    "../../rtl/replaycapsule_v2/rcv2_payload_hasher.sv",
    "../../rtl/replaycapsule_v2/rcv2_address_dictionary.sv",
    "../../rtl/replaycapsule_v2/rcv2_adaptive_window.sv",
    "../../rtl/replaycapsule_v2/rcv2_event_packer.sv",
    "../../rtl/replaycapsule_v2/rcv2_event_fifo_bram.sv",
    "../../rtl/replaycapsule_v2/rcv2_event_stream_fifo.sv",
    "../../rtl/replaycapsule_v2/rcv2_recorder.sv",
    "../../rtl/replaycapsule_v2/rcv2_mmio_replay_driver.sv",
    "../../rtl/replaycapsule_v2/rcv2_irq_replay_driver.sv",
    "../../rtl/replaycapsule_v2/rcv2_replay_consumer.sv",
)


PICORV32_WRAPPER_SOURCES = (
    "tb_picorv32_wrapper_smoke.sv",
    "../../third_party/picorv32/picorv32.v",
    "../../rtl/event_tap.sv",
    "../../rtl/event_classifier.sv",
    "../../rtl/capsule_buffer.sv",
    "../../rtl/property_checker.sv",
    "../../rtl/event_slicer.sv",
    "../../rtl/hash_signature.sv",
    "../../rtl/replay_capsule_top.sv",
    *PICORV32_WRAPPER_V2_SOURCES,
    "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv",
)

PICORV32_INCLUDE_DIRS = ("../../rtl", "../../rtl/replaycapsule_v2", "../../rtl/rv32i_integration", "../../third_party/picorv32")


IVERILOG_TESTS = (
    IverilogTest(
        name="tb_property_checker",
        workdir=Path("tb/system"),
        sources=("tb_property_checker.sv", "../../rtl/property_checker.sv"),
        include_dirs=("../../rtl",),
    ),
    IverilogTest(
        name="tb_capsule_buffer",
        workdir=Path("tb/system"),
        sources=("tb_capsule_buffer.sv", "../../rtl/capsule_buffer.sv"),
        include_dirs=("../../rtl",),
    ),
    IverilogTest(
        name="tb_replay_control",
        workdir=Path("tb/system"),
        sources=("tb_replay_control.sv", "../../rtl/replay_control.sv"),
        include_dirs=("../../rtl",),
    ),
    IverilogTest(
        name="tb_event_classifier_slicer",
        workdir=Path("tb/system"),
        sources=("tb_event_classifier_slicer.sv", "../../rtl/event_classifier.sv", "../../rtl/event_slicer.sv"),
        include_dirs=("../../rtl",),
    ),
    IverilogTest(
        name="tb_hash_signature",
        workdir=Path("tb/system"),
        sources=("tb_hash_signature.sv", "../../rtl/hash_signature.sv"),
        include_dirs=("../../rtl",),
    ),
    IverilogTest(
        name="tb_event_tap",
        workdir=Path("tb/system"),
        sources=("tb_event_tap.sv", "../../rtl/event_tap.sv"),
        include_dirs=("../../rtl",),
    ),
    IverilogTest(
        name="tb_mmio_interrupt_loggers",
        workdir=Path("tb/system"),
        sources=("tb_mmio_interrupt_loggers.sv", "../../rtl/mmio_logger.sv", "../../rtl/interrupt_logger.sv"),
        include_dirs=("../../rtl",),
    ),
    IverilogTest(
        name="tb_registers",
        workdir=Path("tb/system"),
        sources=("tb_registers.sv", "../../rtl/registers.sv"),
        include_dirs=("../../rtl",),
    ),
    IverilogTest(
        name="tb_replaycapsule_soc",
        workdir=Path("tb/system"),
        sources=(
            "tb_replaycapsule_soc.sv",
            "../../rtl/event_tap.sv",
            "../../rtl/event_classifier.sv",
            "../../rtl/capsule_buffer.sv",
            "../../rtl/property_checker.sv",
            "../../rtl/event_slicer.sv",
            "../../rtl/hash_signature.sv",
            "../../rtl/replay_capsule_top.sv",
            "../../rtl/rv32i_integration/replaycapsule_soc.sv",
        ),
        include_dirs=("../../rtl", "../../rtl/rv32i_integration"),
    ),
    IverilogTest(
        name="tb_picorv32_sensor_threshold_smoke",
        workdir=Path("tb/system"),
        sources=(
            "tb_picorv32_wrapper_smoke.sv",
            "../../third_party/picorv32/picorv32.v",
            "../../rtl/event_tap.sv",
            "../../rtl/event_classifier.sv",
            "../../rtl/capsule_buffer.sv",
            "../../rtl/property_checker.sv",
            "../../rtl/event_slicer.sv",
            "../../rtl/hash_signature.sv",
            "../../rtl/replay_capsule_top.sv",
            "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv",
        ),
        include_dirs=("../../rtl", "../../rtl/rv32i_integration", "../../third_party/picorv32"),
        run_args=(
            "+MEMFILE=firmware/build/sensor_threshold_bug/failing.mem",
            "+EXPECTED_PROPERTY=3",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_mmio_ordering_smoke",
        workdir=Path("tb/system"),
        sources=(
            "tb_picorv32_wrapper_smoke.sv",
            "../../third_party/picorv32/picorv32.v",
            "../../rtl/event_tap.sv",
            "../../rtl/event_classifier.sv",
            "../../rtl/capsule_buffer.sv",
            "../../rtl/property_checker.sv",
            "../../rtl/event_slicer.sv",
            "../../rtl/hash_signature.sv",
            "../../rtl/replay_capsule_top.sv",
            "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv",
        ),
        include_dirs=("../../rtl", "../../rtl/rv32i_integration", "../../third_party/picorv32"),
        run_args=(
            "+MEMFILE=firmware/build/mmio_ordering_bug/failing.mem",
            "+EXPECTED_PROPERTY=5",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_interrupt_race_smoke",
        workdir=Path("tb/system"),
        sources=(
            "tb_picorv32_wrapper_smoke.sv",
            "../../third_party/picorv32/picorv32.v",
            "../../rtl/event_tap.sv",
            "../../rtl/event_classifier.sv",
            "../../rtl/capsule_buffer.sv",
            "../../rtl/property_checker.sv",
            "../../rtl/event_slicer.sv",
            "../../rtl/hash_signature.sv",
            "../../rtl/replay_capsule_top.sv",
            "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv",
        ),
        include_dirs=("../../rtl", "../../rtl/rv32i_integration", "../../third_party/picorv32"),
        run_args=(
            "+MEMFILE=firmware/build/interrupt_race_bug/failing.mem",
            "+EXPECTED_PROPERTY=2",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=900",
            "+IRQ_AFTER_COMMAND=1",
            "+IRQ_PULSE_CYCLES=24",
            "+DUMP_CAPSULE=1",
        ),
        defines=("RC_IRQ_VECTOR_WORD_INDEX=12",),
    ),
    IverilogTest(
        name="tb_picorv32_stack_corruption_smoke",
        workdir=Path("tb/system"),
        sources=(
            "tb_picorv32_wrapper_smoke.sv",
            "../../third_party/picorv32/picorv32.v",
            "../../rtl/event_tap.sv",
            "../../rtl/event_classifier.sv",
            "../../rtl/capsule_buffer.sv",
            "../../rtl/property_checker.sv",
            "../../rtl/event_slicer.sv",
            "../../rtl/hash_signature.sv",
            "../../rtl/replay_capsule_top.sv",
            "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv",
        ),
        include_dirs=("../../rtl", "../../rtl/rv32i_integration", "../../third_party/picorv32"),
        run_args=(
            "+MEMFILE=firmware/build/stack_corruption_bug/failing.mem",
            "+EXPECTED_PROPERTY=4",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_uart_command_smoke",
        workdir=Path("tb/system"),
        sources=(
            "tb_picorv32_wrapper_smoke.sv",
            "../../third_party/picorv32/picorv32.v",
            "../../rtl/event_tap.sv",
            "../../rtl/event_classifier.sv",
            "../../rtl/capsule_buffer.sv",
            "../../rtl/property_checker.sv",
            "../../rtl/event_slicer.sv",
            "../../rtl/hash_signature.sv",
            "../../rtl/replay_capsule_top.sv",
            "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv",
        ),
        include_dirs=("../../rtl", "../../rtl/rv32i_integration", "../../third_party/picorv32"),
        run_args=(
            "+MEMFILE=firmware/build/uart_command_bug/failing.mem",
            "+EXPECTED_PROPERTY=1",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=85",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_watchdog_timeout_smoke",
        workdir=Path("tb/system"),
        sources=(
            "tb_picorv32_wrapper_smoke.sv",
            "../../third_party/picorv32/picorv32.v",
            "../../rtl/event_tap.sv",
            "../../rtl/event_classifier.sv",
            "../../rtl/capsule_buffer.sv",
            "../../rtl/property_checker.sv",
            "../../rtl/event_slicer.sv",
            "../../rtl/hash_signature.sv",
            "../../rtl/replay_capsule_top.sv",
            "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv",
        ),
        include_dirs=("../../rtl", "../../rtl/rv32i_integration", "../../third_party/picorv32"),
        run_args=(
            "+MEMFILE=firmware/build/watchdog_timeout_bug/failing.mem",
            "+EXPECTED_PROPERTY=6",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=900",
            "+DUMP_CAPSULE=1",
        ),
        defines=("RC_ENABLE_WATCHDOG",),
    ),
    IverilogTest(
        name="tb_picorv32_sensor_threshold_fixed_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/sensor_threshold_bug/fixed.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_mmio_ordering_fixed_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/mmio_ordering_bug/fixed.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_interrupt_race_fixed_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/interrupt_race_bug/fixed.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
        defines=("RC_IRQ_VECTOR_WORD_INDEX=9",),
    ),
    IverilogTest(
        name="tb_picorv32_stack_corruption_fixed_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/stack_corruption_bug/fixed.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_uart_command_fixed_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/uart_command_bug/fixed.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_watchdog_timeout_fixed_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/watchdog_timeout_bug/fixed.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=300",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
        defines=("RC_ENABLE_WATCHDOG",),
    ),
    IverilogTest(
        name="tb_picorv32_sensor_threshold_below_threshold_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/sensor_threshold_bug/failing.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=300",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_uart_command_no_command_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/uart_command_bug/failing.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=850",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
    ),
    IverilogTest(
        name="tb_picorv32_watchdog_timeout_below_threshold_smoke",
        workdir=Path("tb/system"),
        sources=PICORV32_WRAPPER_SOURCES,
        include_dirs=PICORV32_INCLUDE_DIRS,
        run_args=(
            "+MEMFILE=firmware/build/watchdog_timeout_bug/failing.mem",
            "+EXPECTED_PROPERTY=0",
            "+SENSOR_VALUE=300",
            "+COMMAND_VALUE=0",
            "+MAX_CYCLES=300",
            "+DUMP_CAPSULE=1",
        ),
        defines=("RC_ENABLE_WATCHDOG",),
    ),
    IverilogTest(
        name="tb_rcv2_minimal_recorder",
        workdir=Path("tb/system"),
        sources=(
            "tb_rcv2_minimal_recorder.sv",
            "../../rtl/replaycapsule_v2/rcv2_event_packer.sv",
            "../../rtl/replaycapsule_v2/rcv2_mmio_replay_driver.sv",
            "../../rtl/replaycapsule_v2/rcv2_irq_replay_driver.sv",
            "../../rtl/replaycapsule_v2/rcv2_replay_consumer.sv",
            "../../rtl/replaycapsule_v2/rcv2_recorder.sv",
        ),
        include_dirs=("../../rtl", "../../rtl/replaycapsule_v2"),
    ),
)


COMMON_RTL = (
    "rtl/event_pkg.sv",
    "rtl/event_tap.sv",
    "rtl/event_classifier.sv",
    "rtl/capsule_buffer.sv",
    "rtl/property_checker.sv",
    "rtl/event_slicer.sv",
    "rtl/hash_signature.sv",
    "rtl/replay_capsule_top.sv",
)

ROOT_V2_RTL = tuple(path.replace("../../", "") for path in PICORV32_WRAPPER_V2_SOURCES)


VERILATOR_TARGETS = (
    VerilatorLintTarget(
        name="verilator_lint_replay_capsule_top",
        top="replay_capsule_top",
        sources=COMMON_RTL,
        include_dirs=("rtl",),
    ),
    VerilatorLintTarget(
        name="verilator_lint_picorv32_wrapper",
        top="picorv32_replaycapsule_wrapper",
        sources=("third_party/picorv32/picorv32.v", *COMMON_RTL, *ROOT_V2_RTL, "rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv"),
        include_dirs=("rtl", "rtl/replaycapsule_v2", "rtl/rv32i_integration", "third_party/picorv32"),
    ),
    VerilatorLintTarget(
        name="verilator_lint_replaycapsule_soc",
        top="replaycapsule_soc",
        sources=(*COMMON_RTL, "rtl/rv32i_integration/replaycapsule_soc.sv"),
        include_dirs=("rtl", "rtl/rv32i_integration"),
    ),
    VerilatorLintTarget(
        name="verilator_lint_replay_capsule_properties",
        top="replay_capsule_properties",
        sources=("rtl/event_pkg.sv", "formal/sv_assertions/replay_capsule_properties.sv"),
        include_dirs=("rtl", "formal/sv_assertions"),
    ),
)


def main() -> int:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    BUILD_DIR.mkdir(parents=True, exist_ok=True)

    rows: list[dict[str, str]] = []
    failures: list[str] = []
    _run_iverilog_tests(rows, failures)
    _run_verilator_lint(rows, failures)
    _write_rows(rows)
    print(f"WROTE {OUT_CSV}")
    return 1 if failures else 0


def _run_iverilog_tests(rows: list[dict[str, str]], failures: list[str]) -> None:
    iverilog = _find_tool("iverilog")
    vvp = _find_tool("vvp")
    if not iverilog or not vvp:
        for test in IVERILOG_TESTS:
            rows.append(_row(test.name, "TODO", "iverilog/vvp", "", "Icarus Verilog or vvp not available"))
        return

    for test in IVERILOG_TESTS:
        cwd = REPO_ROOT / test.workdir
        output_path = BUILD_DIR / f"{test.name}.vvp"
        compile_log = RAW_DIR / f"{test.name}_iverilog_compile.txt"
        run_log = RAW_DIR / f"{test.name}_vvp_run.txt"
        compile_cmd = [iverilog.command, "-g2012"]
        include_dirs = _augment_picorv32_include_dirs(test.include_dirs, test.sources)
        sources = _augment_picorv32_sources(test.sources)
        for include_dir in include_dirs:
            compile_cmd.extend(["-I", include_dir])
        for define in test.defines:
            compile_cmd.append(f"-D{define}")
        compile_cmd.extend(["-o", os.path.relpath(output_path, cwd), *sources])
        compile_result = _run(compile_cmd, cwd=cwd, env=iverilog.env)
        compile_log.write_text(_clean_log(compile_result.stdout) or "compile passed without output\n", encoding="utf-8")
        if compile_result.returncode != 0:
            failures.append(f"{test.name} Icarus compile failed")
            rows.append(_row(test.name, "FAIL", iverilog.label, str(compile_log.relative_to(REPO_ROOT)), "compile failed"))
            continue

        run_cmd = [vvp.command, os.path.relpath(output_path, REPO_ROOT), *test.run_args]
        run_result = _run(run_cmd, cwd=REPO_ROOT, env=vvp.env)
        run_log.write_text(_clean_log(run_result.stdout), encoding="utf-8")
        if run_result.returncode != 0:
            failures.append(f"{test.name} vvp run failed")
            rows.append(_row(test.name, "FAIL", vvp.label, str(run_log.relative_to(REPO_ROOT)), "simulation failed"))
            continue

        rows.append(_row(test.name, "PASS", f"{iverilog.label}+{vvp.label}", str(run_log.relative_to(REPO_ROOT)), "compile and simulation passed"))


def _run_verilator_lint(rows: list[dict[str, str]], failures: list[str]) -> None:
    verilator = _find_tool("verilator")
    if not verilator:
        for target in VERILATOR_TARGETS:
            rows.append(_row(target.name, "TODO", "verilator", "", "Verilator not available"))
        return

    for target in VERILATOR_TARGETS:
        log_path = RAW_DIR / f"{target.name}.txt"
        cmd = [verilator.command, "--sv", "--lint-only"]
        for include_dir in target.include_dirs:
            cmd.append(f"-I{include_dir}")
        cmd.extend(["--top-module", target.top, *target.sources])
        result = _run(cmd, cwd=REPO_ROOT, env=verilator.env)
        log_path.write_text(_clean_log(result.stdout), encoding="utf-8")
        if result.returncode != 0:
            failures.append(f"{target.name} failed")
            rows.append(_row(target.name, "FAIL", verilator.label, str(log_path.relative_to(REPO_ROOT)), "lint failed"))
        else:
            rows.append(_row(target.name, "PASS", verilator.label, str(log_path.relative_to(REPO_ROOT)), "lint-only frontend check passed"))


def _augment_picorv32_sources(sources: tuple[str, ...]) -> tuple[str, ...]:
    wrapper = "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv"
    if wrapper not in sources:
        return sources
    out: list[str] = []
    inserted = False
    for source in sources:
        if source == wrapper and not inserted:
            out.extend(item for item in PICORV32_WRAPPER_V2_SOURCES if item not in sources)
            inserted = True
        out.append(source)
    return tuple(out)


def _augment_picorv32_include_dirs(include_dirs: tuple[str, ...], sources: tuple[str, ...]) -> tuple[str, ...]:
    wrapper = "../../rtl/rv32i_integration/picorv32_replaycapsule_wrapper.sv"
    if wrapper not in sources or "../../rtl/replaycapsule_v2" in include_dirs:
        return include_dirs
    return ("../../rtl/replaycapsule_v2", *include_dirs)


def _find_tool(name: str) -> Tool | None:
    system_tool = shutil.which(name)
    if system_tool:
        return Tool(system_tool, name, dict(os.environ))

    local_name = "verilator_bin.exe" if name == "verilator" else f"{name}.exe"
    local_path = OSS_CAD_SUITE / "bin" / local_name
    if local_path.exists():
        return Tool(str(_short_path(local_path)), f"oss-cad-suite:{name}", _oss_env(verilator=name == "verilator"))

    return None


def _oss_env(verilator: bool = False) -> dict[str, str]:
    env = dict(os.environ)
    suite = _short_path(OSS_CAD_SUITE)
    env["PATH"] = os.pathsep.join([str(suite / "bin"), str(suite / "lib"), env.get("PATH", "")])
    if verilator:
        env["VERILATOR_ROOT"] = str(suite / "share" / "verilator")
    return env


def _short_path(path: Path) -> Path:
    if os.name != "nt":
        return path
    try:
        import ctypes

        buffer = ctypes.create_unicode_buffer(1024)
        result = ctypes.windll.kernel32.GetShortPathNameW(str(path), buffer, len(buffer))
        if result:
            return Path(buffer.value)
    except Exception:
        pass
    return path


def _run(command: list[str], cwd: Path, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )


def _clean_log(text: str) -> str:
    text = re.sub(
        r"Walltime [0-9.]+ s \(elab=[0-9.]+, cvt=[0-9.]+, bld=[0-9.]+\); "
        r"cpu [0-9.]+ s on ([0-9]+) threads; allocated [0-9.]+ MB",
        r"Walltime <time> (elab=<time>, cvt=<time>, bld=<time>); cpu <time> on \1 threads; allocated <mem> MB",
        text,
    )
    text = re.sub(r"((?:[A-Za-z0-9_./\\-]+)\.sv):\d+:", r"\1:<line>:", text)
    lines = [line.rstrip() for line in text.splitlines()]
    return "\n".join(lines) + "\n" if lines else ""


def _write_rows(rows: list[dict[str, str]]) -> None:
    with OUT_CSV.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["check", "status", "tool", "raw_log", "notes"])
        writer.writeheader()
        writer.writerows(rows)


def _row(check: str, status: str, tool: str, raw_log: str, notes: str) -> dict[str, str]:
    return {"check": check, "status": status, "tool": tool, "raw_log": raw_log, "notes": notes}


if __name__ == "__main__":
    raise SystemExit(main())
