# Paper Figures

This directory is the landing zone for final paper-ready figure and table
assets. It mirrors generated SVG status figures from `../../results/figures/`
and includes generated Markdown table sources derived from `../../results/`.

Do not manually type measurement values into paper figures or tables. Numeric
content must come from generated CSV, JSON, SVG, or synthesis-report artifacts.

## Current Generated Sources

| Source | Generated today? | Role |
| --- | --- | --- |
| `../../results/raw/phase12_sensor_threshold_trace.json` | Yes | Smoke event timeline for model and replay-flow figures. |
| `../../results/processed/replay_experiments.csv` | Yes | Replay-flow status source. |
| `../../results/processed/rtl_capsule_exports.csv` | Yes | RTL-smoke capsule export, missing-event, duplicate-event, metadata-corruption, payload-corruption, order-corruption, and PC-context source. |
| `../../results/processed/rtl_capsule_event_classes.csv` | Yes | RTL-smoke capsule packet-class source. |
| `../../results/processed/rtl_firmware_alignment.csv` | Yes | RTL-smoke versus firmware-sim property/key-event alignment source. |
| `../../results/processed/randomized_interrupt_campaign.csv` | Yes | Seeded RTL-smoke interrupt campaign source. |
| `../../results/processed/randomized_interrupt_summary.csv` | Yes | Seeded interrupt campaign family/overall summary source. |
| `../../results/processed/randomized_interrupt_coverage.csv` | Yes | Seeded interrupt campaign coverage/TODO checklist source. |
| `../../results/processed/randomized_interrupt_corruption.csv` | Yes | Seeded interrupt corruption-rejection source. |
| `../../results/processed/trace_sizes.csv` | Yes | Baseline trace-size data source. |
| `../../results/figures/trace_size_status.svg` | Yes | Existing generated trace-size status figure; not final paper styling. |
| `../../results/figures/rtl_capsule_event_classes.svg` | Yes | Existing generated RTL-smoke capsule class figure; not final paper styling. |
| `../../results/figures/randomized_interrupt_campaign.svg` | Yes | Existing generated seeded interrupt campaign figure; not final paper styling. |
| `../../results/processed/ablations.csv` | Yes | Ablation heatmap data source. |
| `../../results/processed/rtl_smoke_ablations.csv` | Yes | RTL-smoke exported-capsule event-class ablation source. |
| `../../results/processed/rtl_smoke_event_sufficiency.csv` | Yes | Required event classes for failing RTL-smoke capsules. |
| `../../results/processed/hdl_checks.csv` | Yes | Directed HDL and PicoRV32 wrapper smoke verification source with nine directed module rows and fifteen wrapper smoke rows. |
| `../../results/processed/picorv32_smoke_summary.csv` | Yes | Log-level PicoRV32 wrapper smoke capsule observation source. |
| `../../results/processed/picorv32_smoke_coverage.csv` | Yes | PicoRV32 wrapper smoke coverage/sanity-check source. |
| `../../results/processed/benchmark_coverage.csv` | Yes | Per-benchmark local evidence coverage source. |
| `../../results/processed/formal_checks.csv` | Yes | Bounded event-tap, event-classifier/slicer, property-checker, hash-signature, MMIO/interrupt logger, register, replay-control, replay-mismatch, capsule-buffer, and recorder formal status source. |
| `../../results/processed/formal_coverage.csv` | Yes | Reviewer-facing mapping from formal BMC/cover targets to RTL contract families and explicit limits. |
| `../../results/processed/overflow_contracts.csv` | Yes | Bounded overflow contract evidence source. |
| `../../results/raw/yosys_picorv32.txt` | Yes | Yosys generic synthesis report for the baseline PicoRV32 core. |
| `../../results/raw/yosys_replay_capsule_top.txt` | Yes | Yosys generic synthesis report for the record-side top. |
| `../../results/raw/yosys_picorv32_replaycapsule_wrapper.txt` | Yes | Yosys generic synthesis report for the integrated wrapper. |
| `../../results/processed/synthesis.csv` | Yes | Synthesis/resource table source with generic cells measured. |
| `../../results/processed/synthesis_overhead.csv` | Yes | Derived generic cell-overhead context. |
| `../../results/processed/mapped_synthesis.csv` | Yes | Same-target mapped FPGA resource/timing source. |
| `../../results/processed/mapped_overhead.csv` | Yes | Same-target mapped FPGA overhead source. |
| `table01_synthesis_resources.md` | Yes | Generated Markdown source for the synthesis/resource table. |
| `table02_replay_evidence.md` | Yes | Generated Markdown source for replay evidence status. |
| `table03_trace_baselines.md` | Yes | Generated Markdown source for trace-size baselines. |
| `table04_event_sufficiency.md` | Yes | Generated Markdown source for event-sufficiency ablations. |
| `table05_formal_coverage.md` | Yes | Generated Markdown source for bounded formal coverage. |
| `../../results/processed/proof_obligations.csv` | Yes | Replay-sufficiency proof-obligation source. |
| `../../docs/proof_obligation_matrix.md` | Yes | Reviewer-facing proof-obligation matrix. |
| `table06_proof_obligations.md` | Yes | Generated Markdown source for replay-sufficiency proof obligations. |
| `../../results/processed/evaluation_metrics.csv` | Yes | Headline evaluation metric rollup source with measured replay, runtime, mapped overhead, and explicit unsupported TODO/NA rows. |
| `table07_evaluation_metrics.md` | Yes | Generated Markdown source for evaluation metric rollup. |
| `../../results/processed/claim_audit.csv` | Yes | Claim-audit source for honesty-gate review. |
| `../../results/processed/toolchain_status.csv` | Yes | Tool availability and missing-blocker ledger. |
| `../../results/processed/artifact_manifest.csv` | Yes | SHA-256 hash manifest for main generated evidence files. |
| `../../results/processed/summary.csv` | Yes | Provenance and missing-tool status ledger. |

## Planned Assets

| Output | Status | Source of truth | Missing gate |
| --- | --- | --- | --- |
| `fig01_architecture.svg` / `.pdf` | Not generated | `../../docs/architecture.md`, `../../docs/event_interface.md`, `../../rtl/*.sv` | None for record-side diagram; PicoRV32 artifact required before claiming completed SoC integration. |
| `fig02_event_model.svg` / `.pdf` | Partial source generated | `../../docs/event_model.md`, `../../results/raw/phase12_sensor_threshold_trace.json` | Full benchmark timeline requires RTL/PicoRV32 traces. |
| `fig03_replay_flow.svg` / `.pdf` | Partial source generated | `../../results/processed/replay_experiments.csv`, replay testbench scripts | Full benchmark replay requires RTL/PicoRV32 traces. |
| `fig04_baseline_trace_sizes.svg` / `.pdf` | Status SVG generated today | `../../results/processed/trace_sizes.csv`, `../../results/figures/trace_size_status.svg` | Missing baselines and replay-success fields require simulator/RTL/PicoRV32 artifacts. |
| `fig05_ablation_heatmap.svg` / `.pdf` | CSV generated today; heatmap not generated | `../../results/processed/ablations.csv` | Full-suite rows require firmware-running RTL/PicoRV32 traces. |
| `fig06_rtl_capsule_event_classes.svg` / `.pdf` | Status SVG generated today | `../../results/processed/rtl_capsule_event_classes.csv`, `../../results/figures/rtl_capsule_event_classes.svg` | Full RTL replay success is reported separately from smoke-capsule event-class coverage. |
| `fig07_randomized_interrupt_campaign.svg` / `.pdf` | Status SVG generated today | `../../results/processed/randomized_interrupt_campaign.csv`, `../../results/processed/randomized_interrupt_summary.csv`, `../../results/processed/randomized_interrupt_coverage.csv`, `../../results/processed/randomized_interrupt_corruption.csv`, `../../results/figures/randomized_interrupt_campaign.svg` | Stronger randomized full RTL campaigns are future work. |
| `table01_synthesis_resources.md` | Generated table today | `../../results/processed/synthesis.csv`, `../../results/processed/synthesis_overhead.csv`, `../../results/processed/mapped_synthesis.csv`, `../../results/processed/mapped_overhead.csv` | Same-target ECP5 mapped rows are reported separately from generic Yosys context. |
| `table02_replay_evidence.md` | Generated table today | `../../results/processed/replay_experiments.csv`, `../../results/processed/rtl_firmware_alignment.csv`, `../../results/processed/full_rtl_replay.csv`, `../../results/processed/full_rtl_replay_negative.csv` | Host-driven full RTL replay suite is the current replay evidence. |
| `table03_trace_baselines.md` | Generated partial table today | `../../results/processed/trace_sizes.csv`, `../../results/processed/rtl_capsule_event_classes.csv` | Full benchmark-wide RTL trace-size rows and mapped/replay-backed reductions. |
| `table04_event_sufficiency.md` | Generated partial table today | `../../results/processed/event_sufficiency.csv`, `../../results/processed/ablations.csv`, `../../results/processed/rtl_smoke_event_sufficiency.csv` | Full benchmark-wide RTL-backed ablations. |
| `table05_formal_coverage.md` | Generated table today | `../../results/processed/formal_coverage.csv` | End-to-end proof remains outside current bounded checks. |
| `table06_proof_obligations.md` | Generated partial table today | `../../results/processed/proof_obligations.csv` | End-to-end mechanized theorem remains outside current bounded checks. |
| `table07_evaluation_metrics.md` | Generated table today | `../../results/processed/evaluation_metrics.csv` | Runtime overflow counters and broader benchmark expansions. |

## Rendering Rules

- Keep final plot data in `../../results/processed/*`.
- Keep raw logs and traces in `../../results/raw/*`.
- Treat `TODO` and `NA` as first-class paper states for unsupported rows, not
  as permission to estimate missing numbers.
- Captions may describe the measurement method, but must not introduce numbers
  that are absent from the source artifacts.
- If a final figure is restyled for publication, record the exact source CSV or
  JSON path in its caption notes or adjacent metadata.

## Required Before Submission

| Requirement | Applies to |
| --- | --- |
| Additional firmware-running PicoRV32 trace exports | Full RTL-backed baseline sizes and ablation heatmap. |
| Expanded Verilator or cocotb RTL campaigns | Broader event logs, runtime overflow counters, and stress coverage. |
| Yosys reports parsed into `synthesis.csv` and `synthesis_overhead.csv` | Synthesis/resource table. |
| Proof-obligation matrix generated from theorem assumptions and result artifacts | Formal/replay-sufficiency table. |
| Additional mapped FPGA reports beyond the current ECP5 rows | Cross-target or optimized LUT/FF/BRAM/Fmax and overhead fields. |
