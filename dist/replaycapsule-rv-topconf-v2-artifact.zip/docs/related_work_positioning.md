# Related Work Positioning

ReplayCapsule-RV should be positioned as a focused prototype for event-sufficient replay of single-hart RV32I interrupt/MMIO failures.

## Positioning Statement

ReplayCapsule-RV explores a middle point between full instruction tracing, coarse failure snapshots, and property-only logs. It records a compact set of replay-critical events plus optional diagnostics, then checks that replay agrees with the recorded failure signature and event stream.

## What The Project Does

- Runs compiler-backed firmware through RTL record/replay flows.
- Rejects corrupted capsule streams in negative replay.
- Measures workload scaling, buffer sensitivity, capsule baselines, runtime scaling, and ECP5 mapping for v1.
- Adds v2 RTL for compressed event packing, address dictionary tagging, payload hashing, adaptive diagnostic dropping, and BRAM-style event storage.
- Adds a synthesizable v2 replay-consume controller prototype with corruption tests.

## What The Project Does Not Claim

- It is not a full-system replay framework.
- It is not a multicore, cache, coherence, DMA, or OS replay system.
- It is not a replacement for trace/debug standards.
- It does not prove globally minimal event sets.
- It does not yet provide full-core v2 replay success or full-core v2 overhead numbers.

## Reviewer-Safe Contribution Wording

"ReplayCapsule-RV explores event-sufficient failure capsules for replaying single-hart RV32I interrupt/MMIO failures, combining compiler-backed firmware-running RTL replay, corruption rejection, mapped recorder evidence, and scaling analysis."

"ReplayCapsule-RV v2 adds an adaptive compressed capsule format and synthesizable replay-consume controller prototype."

## Current Risk Framing

The strongest current claims remain v1 replay correctness and corruption rejection. v2 improves the architecture and adds a real replay-consume prototype, but workload replay and mapped full-core overhead are still blocked until v2 is integrated into the full-core harness.

